SET SERVEROUTPUT ON;
SET VERIFY OFF;

--add new Vehicle
CREATE OR REPLACE Trigger VehicleInserted
after insert 
on Vehicle

BEGIN
    DBMS_OUTPUT.PUT_LINE('New Vehicle added.');
END;
/

ACCEPT VNAM char PROMPT "Vehicle name = "
ACCEPT AVAI char PROMPT "Availability = "
ACCEPT MODN char PROMPT "Model no = "
ACCEPT REGN char PROMPT "Registration no = "
ACCEPT PRIC char PROMPT "Rent Price = "

DECLARE
    vnum NUMBER;
    vname Vehicle.Vehicle_Name%TYPE;
    avail Vehicle.Availability%TYPE;
    model Vehicle.Model_no%TYPE;
    regno Vehicle.RegNo%TYPE;
    price NUMBER;

BEGIN
    DBMS_OUTPUT.PUT_LINE('Add New Vehicle:');
    vname := '&VNAM';
    avail := '&AVAI';
    model := '&MODN';
    regno := '&REGN';
    price := '&PRIC';

    
    select count(Vehicle_Id) into vnum from Vehicle;
    insert into Vehicle values (vnum+1,vname,avail,model,regno,price);

END;
/



commit;