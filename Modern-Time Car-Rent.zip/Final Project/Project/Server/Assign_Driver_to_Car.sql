SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE Trigger DriverAssigned
after insert 
on Assigned

BEGIN
    DBMS_OUTPUT.PUT_LINE('Driver assigned to Vehicle');
END;
/


CREATE OR REPLACE PROCEDURE assignDriver(D IN int,V IN int)
IS
    serial_no int;
    flag int;
BEGIN
    flag := 1;
    FOR R IN (SELECT * FROM Assigned) LOOP
        IF R.Dri_Id = D AND R.Vehi_Id = V then
            flag :=0;
        END IF;
    END LOOP;
    
    IF flag = 1 then
        SELECT count(A_ID) into serial_no FROM Assigned;
        insert into Assigned values(serial_no+1,D,V);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Data already exists');
    END IF;

END assignDriver;
/

ACCEPT CARID NUMBER PROMPT "Car ID = ";
ACCEPT DRIID NUMBER PROMPT "Driver ID = ";

DECLARE
    drID int;
    carID int;
BEGIN
    drID  := '&DRIID';
    carID := '&CARID';

    assignDriver(drID,carID);
END;
/

