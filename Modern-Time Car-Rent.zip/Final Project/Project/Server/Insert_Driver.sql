SET SERVEROUTPUT ON;
SET VERIFY OFF;

-- add new driver
CREATE OR REPLACE Trigger DriverInserted
after insert 
on Driver

BEGIN
    DBMS_OUTPUT.PUT_LINE('New Driver added');
END;
/


ACCEPT DNAM char PROMPT "Drivers name = "
ACCEPT CONT char PROMPT "Drivers Contact = "
ACCEPT AGE  number  PROMPT "Age of the Driver = "
ACCEPT DRL  char PROMPT "Driving License = ";


DECLARE

    dnum NUMBER;
    dname Driver.NAME%TYPE;
    cont  Driver.CONTACT%TYPE;
    age NUMBER;
    driL Driver.DrivingLicence%TYPE;

BEGIN

    DBMS_OUTPUT.PUT_LINE('Add New Driver:');
    dname := '&DNAM';
    cont  := '&CONT';
    age   := '&AGE';
    driL  := '&DRL';

    
    select count(DriId) into dnum from Driver;
    insert into Driver values (dnum+1,dname,cont,age,driL);

END;
/



commit;