SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE PROCEDURE show_My_Bookings
IS

BEGIN
    DBMS_OUTPUT.PUT_LINE('Book_ID'||'   '||'CUSTOMER_NAME'||'    '||'Vehicle_Name'||'    '||'DRI NAME'||'      '||'R.date_');
    FOR R IN (SELECT * FROM Bookings@site_link_1 B INNER JOIN Driver D ON B.DRIVER_ID=D.DriId INNER JOIN Vehicle V ON B.CAR_ID=V.Vehicle_Id) LOOP
        DBMS_OUTPUT.PUT_LINE(R.Book_ID||'   '||R.CUSTOMER_NAME||'         '||R.Vehicle_Name||'           '||R.NAME||'  '||R.date_);
    END LOOP;
    FOR R IN (SELECT * FROM Bookings@site_link_2 B INNER JOIN Driver D ON B.DRIVER_ID=D.DriId INNER JOIN Vehicle V ON B.CAR_ID=V.Vehicle_Id) LOOP
        DBMS_OUTPUT.PUT_LINE(R.Book_ID||'   '||R.CUSTOMER_NAME||'         '||R.Vehicle_Name||'           '||R.NAME||'  '||R.date_);
    END LOOP;
END show_My_Bookings;
/

BEGIN
    show_My_Bookings;
END;
/
