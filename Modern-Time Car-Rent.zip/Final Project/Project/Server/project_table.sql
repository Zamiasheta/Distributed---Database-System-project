SET SERVEROUTPUT ON;
SET VERIFY OFF;

clear screen;

drop table Driver ;
drop table Vehicle ;
drop table Assigned ;



create table Vehicle(
Vehicle_Id     integer,
Vehicle_Name   varchar2(30), 
Availability   varchar2(30),       
Model_no       varchar2(30),
RegNo          varchar2(30),
Price          integer,
PRIMARY KEY(Vehicle_Id));

create table Driver(
DriId     integer, 
NAME      varchar2(30),       
CONTACT   varchar2(30),
Age       integer,
DrivingLicence varchar2(30),
PRIMARY KEY(DriId));

create table Assigned(
A_ID  integer,
Dri_Id integer,
Vehi_Id integer
);

insert into Vehicle values(1,'A','Yes','A452','NY12365',12000);
insert into Vehicle values(2,'B','Yes','B423','CA12365',12000);
insert into Vehicle values(3,'E','No','E125','SA12365',12000);
insert into Vehicle values(4,'D','Yes','D126','DE12365',12000);
insert into Vehicle values(5,'F','No','F153','MI12365',12000);
insert into Vehicle values(6,'V','Yes','V888','CA12365',12000);

insert into Driver values(1,'Jon','017155231',21,'123456');
insert into Driver values(2,'Davis','017165231',44,'156832');
insert into Driver values(3,'Boris','017115231',32,'125356');
insert into Driver values(4,'Rick','017255231',23,'123568');
insert into Driver values(5,'Ali','017165231',26,'123569');
insert into Driver values(6,'Aman','017155831',30,'123658');

insert into Assigned values(1,1,1);
insert into Assigned values(2,1,2);
insert into Assigned values(3,2,3);
insert into Assigned values(4,3,4);
insert into Assigned values(5,3,5);
insert into Assigned values(6,4,5);
insert into Assigned values(7,5,6);
insert into Assigned values(8,6,6);





commit;

