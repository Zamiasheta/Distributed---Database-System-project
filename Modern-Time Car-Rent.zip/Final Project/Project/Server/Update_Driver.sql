SET SERVEROUTPUT ON;
SET VERIFY OFF;
    
 ACCEPT DNUM NUMBER PROMPT "Drivers ID = ";
 ACCEPT DNAM char PROMPT "Drivers Updated name = ";
 ACCEPT CONT char PROMPT "Drivers Updated Contact = ";
 ACCEPT AGE  NUMBER  PROMPT "Updated Age of the Driver = ";
 ACCEPT DRL  char PROMPT "Updated Driving License = ";

DECLARE
    dnum  NUMBER;
    dname Driver.NAME%TYPE;
    cont  Driver.CONTACT%TYPE;
    age   NUMBER;
    driL  Driver.DrivingLicence%TYPE;
    
    
BEGIN
    dnum  := '&DNUM';
    dname := '&DNAM';
    cont  := '&CONT';
    age   := '&AGE';
    driL  := '&DRL';

    UPDATE Driver D SET D.NAME=dname, D.CONTACT=cont, D.Age=age, D.DrivingLicence=driL WHERE D.DriId=dnum ;
    DBMS_OUTPUT.PUT_LINE('Driver Updated');

END;
/
commit;