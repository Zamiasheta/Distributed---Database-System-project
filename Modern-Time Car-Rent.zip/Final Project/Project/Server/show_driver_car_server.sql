--show cars and associeted drivers
SET SERVEROUTPUT ON;
SET VERIFY OFF;

clear screen;


CREATE OR REPLACE PROCEDURE getVehicleDrivers(CAR IN CHAR)
IS
    
    vid       Vehicle.Vehicle_Id%TYPE;
    NAME      Driver.NAME%TYPE;       
    CONTACT   Driver.CONTACT%TYPE;
    Age       Driver.Age%TYPE;
    VName     Vehicle.Vehicle_Name%TYPE;
    driId     Driver.DriId%TYPE;
    Availability   varchar2(30);       
    Model_no       varchar2(30);
    RegNo          varchar2(30);
    LicenceNo      varchar2(30);
    price          int;  

BEGIN
    FOR R IN (SELECT * FROM Driver D INNER JOIN Assigned A ON D.DriId=A.Dri_Id INNER JOIN Vehicle V ON A.Vehi_Id=V.Vehicle_Id) LOOP
        if R.Vehicle_Name = CAR then
        driId := R.Dri_Id ;
        NAME:=R.NAME;
        CONTACT:=R.CONTACT;
        Age:=R.Age;
        VName:=R.Vehicle_Name;
        LicenceNo := R.DrivingLicence;
        price := R.Price;
        availability:=R.Availability;
        --Model_no := R.Model_no;
        --RegNo := R.RegNo;

        DBMS_OUTPUT.PUT_LINE(driId||'  '||NAME ||'     '||CONTACT ||'     '|| Age||'     '||VName||'     '||LicenceNo||'  '||price||'    '||availability);
        
        END if;
    
    END LOOP;
END getVehicleDrivers;
/

ACCEPT CNAM char PROMPT "Car name = "

DECLARE
    car char;

BEGIN
    car := '&CNAM';
    getVehicleDrivers(car);
    
END;
/
