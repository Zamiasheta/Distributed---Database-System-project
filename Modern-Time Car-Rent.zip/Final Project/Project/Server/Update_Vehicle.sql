SET SERVEROUTPUT ON;
SET VERIFY OFF;

    ACCEPT VNUM NUMBER PROMPT "Vehicle ID = ";
    ACCEPT VNAM char PROMPT "Vehicle name = "
    ACCEPT AVAI char PROMPT "Availability = "
    ACCEPT MODN char PROMPT "Model no = "
    ACCEPT REGN char PROMPT "Registration no = "
    ACCEPT PRIC char PROMPT "Rent Price = "

DECLARE
    vnum NUMBER;
    vname Vehicle.Vehicle_Name%TYPE;
    avail Vehicle.Availability%TYPE;
    model Vehicle.Model_no%TYPE;
    regno Vehicle.RegNo%TYPE;
    price Vehicle.Price%TYPE;
    
BEGIN
    vnum  := '&VNUM';
    vname := '&VNAM';
    avail := '&AVAI';
    model := '&MODN';
    regno := '&REGN';
    price := '&PRIC';

    UPDATE Vehicle V SET V.Vehicle_Name=vname, V.Availability=avail, V.Model_no=model, V.RegNo=regno, V.Price=price WHERE V.Vehicle_Id=vnum ;
    DBMS_OUTPUT.PUT_LINE('Vehicle Updated');

END;
/
commit;