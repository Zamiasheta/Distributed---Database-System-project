SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE PROCEDURE show_My_Bookings
IS

BEGIN
    --@server
    DBMS_OUTPUT.PUT_LINE('Book_ID'||'   '||'CUSTOMER_NAME'||'    '||'Vehicle_Name'||'    '||'Dri NAME'||'  '||'R.date_');
    FOR R IN (SELECT * FROM Bookings B INNER JOIN Driver@server D ON B.DRIVER_ID=D.DriId INNER JOIN Vehicle@server V ON B.CAR_ID=V.Vehicle_Id) LOOP
        DBMS_OUTPUT.PUT_LINE(R.Book_ID||'   '||R.CUSTOMER_NAME||'    '||R.Vehicle_Name||'    '||R.NAME||'  '||R.date_);
    END LOOP;
END show_My_Bookings;
/

CREATE OR REPLACE PROCEDURE show_My_payments
IS

BEGIN
    DBMS_OUTPUT.PUT_LINE('Pay_ID'||'   '||'Price'||'    '||'Due'||'    '||'Pay Date'||'  '||'Status'||'  '||'Book ID');
    FOR R IN (SELECT * FROM Payment P) LOOP
        DBMS_OUTPUT.PUT_LINE(R.Pay_ID||'      '||R.Price||'      '||R.Due||'       '||R.date_||'      '||R.Status||'    '||R.Book_ID);
    END LOOP;
END show_My_payments;
/

ACCEPT PAYID NUMBER PROMPT "Pay ID = ";
ACCEPT PAYAM NUMBER PROMPT "Paid amount = ";

DECLARE
    payID int;
    amount int;
    price int;
    due int;
    stats varchar2(11);
    Date_ varchar2(11);
    rest int;
BEGIN
    show_My_Bookings;
    show_My_payments;

    payID := '&PAYID';
    amount:= '&PAYAM';
    
    select Due , Price into due , price from Payment where Pay_ID=payID;
    
    rest := due - amount;
    Date_ := TO_CHAR(SYSDATE,'yyyy-mm-dd');
    IF rest>0 then
        stats := 'Due';
    ELSE
        stats := 'Complete';
    END IF;
    
    UPDATE Payment P SET P.Due=rest , P.Status=stats, P.date_=Date_ where P.Pay_ID=payID;

    show_My_payments; 

END;
/
