--show cars and associeted drivers
SET SERVEROUTPUT ON;
SET VERIFY OFF;

clear screen;


CREATE OR REPLACE PROCEDURE getVehicleDrivers(CAR IN CHAR)
IS
    
    vid       Vehicle.Vehicle_Id%TYPE;
    NAME      Driver.NAME%TYPE;       
    CONTACT   Driver.CONTACT%TYPE;
    Age       Driver.Age%TYPE;
    VName     Vehicle.Vehicle_Name%TYPE;
    driId     Driver.DriId%TYPE;
    Availability   varchar2(11);       
    Model_no       varchar2(11);
    RegNo          varchar2(11);
    LicenceNo      varchar2(11);
    price          int;  

BEGIN
    --@server
    DBMS_OUTPUT.PUT_LINE('Driver ID'||'     '||'Vehicle ID'||'     '||'Driver Name'||'     '||'Contact'||'     '||'AGE'||'     '||'Vehicle Name'||'     '||'LicenceNo'||'  '||'price');
    FOR R IN (SELECT * FROM Driver@server D INNER JOIN Assigned@server A ON D.DriId=A.Dri_Id INNER JOIN Vehicle@server V ON A.Vehi_Id=V.Vehicle_Id) LOOP
        if R.Vehicle_Name = CAR then
        driId     :=  R.Dri_Id ;
        vid       :=  R.Vehi_Id;
        NAME      :=  R.NAME;
        CONTACT   :=  R.CONTACT;
        Age       :=  R.Age;
        VName     :=  R.Vehicle_Name;
        LicenceNo :=  R.DrivingLicence;
        price     :=  R.Price;
        availability:=R.Availability;
        
        DBMS_OUTPUT.PUT_LINE(driId||'    '||vid||'     '||NAME ||'     '||CONTACT ||'     '|| Age||'     '||VName||'     '||LicenceNo||'  '||price||'    '||availability);
        
        END if;
    
    END LOOP;
END getVehicleDrivers;
/

ACCEPT CNAM char PROMPT "Car name = "

DECLARE
    car char;

BEGIN
    car := '&CNAM';
    getVehicleDrivers(car);
    
END;
/
