SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE Trigger Booked
after insert 
on Bookings

BEGIN
    DBMS_OUTPUT.PUT_LINE('Vehicle booked');
END;
/


CREATE OR REPLACE Trigger PaymentDone
after insert 
on Payment

BEGIN
    DBMS_OUTPUT.PUT_LINE('Payment Complete');
END;
/

ACCEPT CARID NUMBER PROMPT "Car ID = ";
ACCEPT DRIID NUMBER PROMPT "Driver ID = ";
ACCEPT PAID  NUMBER PROMPT "Price payed = ";
ACCEPT NAME  char PROMPT "Your Name = ";
ACCEPT DATE_  char PROMPT "(year-month-date) Date of booking = ";


DECLARE
    carID int;
    driID int;
    bookID int;
    payID int;
    pay   int;
    flag int;
    name     varchar2(30);
    bookdate varchar2(30);
    paydate  varchar2(30);
    Status varchar2(30);
BEGIN
    flag := 0;
    carID    := '&CARID';
    driID    := '&DRIID';
    pay      := '&PAID';
    name     := '&NAME';
    bookdate := '&DATE_';
    
    
    select count(Book_ID) into bookID from Bookings;
    select count(Pay_ID) into payID from Payment;
    --@server
    FOR R IN (SELECT * FROM Driver@server D INNER JOIN Assigned@server A ON D.DriId=A.Dri_Id INNER JOIN Vehicle@server V ON A.Vehi_Id=V.Vehicle_Id) LOOP
        IF R.Dri_Id=driID and R.Vehi_Id=carID  and R.Availability = 'Yes' then
            flag := 1;
            insert into Bookings values(bookID+1,name,carID,driID,bookdate);  
            
            IF (R.Price - pay)>0 then
                Status := 'Due';
                insert into Payment values (payID+1,R.Price,R.Price - pay,bookdate,Status,bookID+1);
            ELSE
                Status := 'Complete';
                insert into Payment values (payID+1,R.Price,0,bookdate,Status,bookID+1);
            END IF;
        END IF;
    
    END LOOP;
    IF flag = 0 then
        DBMS_OUTPUT.PUT_LINE('Car not availble');
    END IF;
END;
/