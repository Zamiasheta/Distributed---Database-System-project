SET SERVEROUTPUT ON;
SET VERIFY OFF;

clear screen;

--Booking table
create table Bookings(
    Book_ID        int,
    CUSTOMER_NAME  varchar2(30),
    CAR_ID         int,
    DRIVER_ID      int,
    date_          varchar2(30)
);

--payment table
create table Payment(
    Pay_ID   int,
    Price    int,
    Due      int,
    date_    varchar2(30),
    Status   varchar2(30),
    Book_ID  int
);

commit;