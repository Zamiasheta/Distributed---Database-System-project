SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE FUNCTION searchCar(CAR IN Vehicle.Vehicle_Name%TYPE,B in out int)
RETURN integer
IS
    vnum Vehicle.Vehicle_Id%TYPE;
    vname Vehicle.Vehicle_Name%TYPE;
    avail Vehicle.Availability%TYPE;
    model Vehicle.Model_no%TYPE;
    regno Vehicle.RegNo%TYPE;
    price Vehicle.Price%TYPE;

BEGIN
    DBMS_OUTPUT.PUT_LINE('ID'||'  '||'NAME'||'  '||'Availabilty'||'  '||'MODEL'||'  '||'REGI_NO'||'  '||'PRICE');
    FOR R IN (Select * FROM Vehicle@server where Vehicle_Name=CAR) LOOP
        vnum  := R.Vehicle_Id;
        vname := R.Vehicle_Name;
        avail := R.Availability;
        model := R.Model_no;
        regno := R.RegNo;
        price := R.Price;

        DBMS_OUTPUT.PUT_LINE(vnum||'  '||vname||'  '||avail||'  '||model||'  '||regno||' '||price);
        B:= vnum;
    END LOOP;
    RETURN B;
END searchCar;
/

ACCEPT VNAM char PROMPT "Vehicle name = " 

DECLARE
    find int;
    car_name Vehicle.Vehicle_Name%TYPE;
BEGIN
    find := 0;
    car_name := '&VNAM';
    find := searchCar(car_name,find);
    if find = 0 then
        RAISE NO_DATA_FOUND;
    ELSE
        
    END if;
    EXCEPTION
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('Car Not Found');
END;
/